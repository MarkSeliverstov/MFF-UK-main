<?php

echo "Hello world";

require_once __DIR__ . '/App/bootstrap.php';

