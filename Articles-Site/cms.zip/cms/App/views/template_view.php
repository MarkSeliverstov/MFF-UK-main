<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>CMS</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' href='lib/style.css'>
    <link rel='stylesheet' type='text/css' href='../lib/style.css'>

</head>
<body>
    <main>
        <?php include $content_view; ?>
    </main>
</body>
</html>

