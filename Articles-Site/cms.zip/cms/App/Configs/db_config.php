<?php
$db_config = [
  'server'   => '',
  'login'    => '',
  'password' => '',
  'database' => '',
];

